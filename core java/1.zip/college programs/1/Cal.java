class Cal
{
public static void main(String args[])
{
int a=10;
int b=5;
int s=a+b;
int p=a*b;
int d=a-b;

System.out.println("sum is ="+s+" difference is ="+d+" product is ="+p);

}
}